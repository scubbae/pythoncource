#My favorate song by Mariaha Carry

artist = "Mariah Cary"

title = "Butterfly"

album = "Butterfly"

releaseDate = "1997"

nomination = "Grammy Award for Best Female Pop Vocal Performance"

genre = "Contemporary R&B"

# I added label for each print out
print('Artist:' + artist)
print('Title:' + title)
print('Album:' + album)
print('Date:' + releaseDate)
print('Nominated:' + nomination)
print('Genre:' + genre)




