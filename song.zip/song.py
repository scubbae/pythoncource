# Function that returns song info

def artist():
    name = "Mariah Carry"
    print(name)


def song():
    title = "Butterfly"
    print(bool(title))


def nominate():
    text = "Grammy Award for Best Female Pop Vocal Performance"
    print(text)


artist()

song()

nominate()
